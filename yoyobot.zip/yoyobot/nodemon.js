{
	"ignore" : [info.json]
}
